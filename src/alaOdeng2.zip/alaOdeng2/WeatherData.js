export const weatherProps = [
  {
    img: "https://source.unsplash.com/random/400x300",
    condition: "bad",
    time: 7,
  },
  {
    img: "https://source.unsplash.com/random/400x300",
    condition: "cool",
    time: 4,
  },
  {
    img: "https://source.unsplash.com/random/400x300",
    condition: "nice",
    time: 9,
  },
  {
    img: "https://source.unsplash.com/random/400x300",
    condition: "fair",
    time: 3,
  },
  {
    img: "https://source.unsplash.com/random/400x300",
    condition: "weak",
    time: 3,
  },
];
